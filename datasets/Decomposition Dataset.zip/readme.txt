>>> python main.py <RESOLUTION>

<RESOLUTION> should be an integer

The code will generate 60,506 overlapped images, whose xdim and ydim is resized to <RESOLUTION>

recommended : 512