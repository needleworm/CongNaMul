import os
import sys

try:
    from PIL import Image
except ModuleNotFoundError:
    import pip
    import time
    pip.main(['install', 'pillow'])
    time.sleep(1)
    try:
        from PIL import Image
    except ModuleNotFoundError:
        import pip
        import time

        pip.main(['install', 'pillow'])
        time.sleep(1)
        from PIL import Image

try:
    import numpy as np
except ModuleNotFoundError:
    import pip
    import time
    pip.main(['install', 'numpy'])
    time.sleep(1)
    try:
        import numpy as np
    except ModuleNotFoundError:
        import pip
        import time

        pip.main(['install', 'numpy'])
        time.sleep(1)
        import numpy as np

try:
    import cv2
except ModuleNotFoundError:
    import pip
    import time
    pip.main(['install', 'opencv-python'])
    time.sleep(1)
    try:
        import cv2
    except ModuleNotFoundError:
        import pip
        import time

        pip.main(['install', 'opencv-python'])
        time.sleep(1)
        import cv2


size = "_" + sys.argv[1]


def overlap_2_msk(img1, img2, d, i, j, preview):
    palette = img1.palette
    a = np.asarray(img1)
    b = np.asarray(img2)

    c = np.maximum(a, b)

    if np.sum(a) > np.sum(b):
        new_filename = d + "_" + str(j) + "_" + str(i)
        res = np.stack((b, a, c), axis=-1)
        order = False
    else:
        new_filename = d + "_" + str(j) + "_" + str(i)
        res = np.stack((a, b, c), axis=-1)
        order = True

    np.save("overlapped_msk_2" + size + "/npy/" + new_filename + ".npy", res)

    if preview:
        img = Image.fromarray(c)
        img.putpalette(palette)
        img.save("overlapped_msk_2" + size + "/preview/" + new_filename + ".png", mode="p")
        img.close()

    return new_filename, order


def histogram_stretch(c):
    # Split the image into its color channels
    channels = cv2.split(c)

    # Create a CLAHE object (Arguments are optional)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))

    # Apply histogram equalization to each color channel
    eq_channels = []
    for ch in channels:
        eq_channels.append(clahe.apply(ch))

    # Merge the channels back together
    return cv2.merge(eq_channels)


def resize_image(img, msk, new_X=2016, new_Y=2016, resizeto=512, histogram_stretch=False):
    image_file = Image.open(img)
    msk_file = Image.open(msk)
    msk_arr = np.asarray(msk_file)
    palette = msk_file.palette
    image_arr = np.asarray(image_file)
    if histogram_stretch:
        image_arr = histogram_stretch(image_arr)
    image_file.close()
    msk_file.close()

    n_x, n_y = np.nonzero(msk_arr)
    y1 = np.min(n_y)
    y2 = np.max(n_y)
    x1 = np.min(n_x)
    x2 = np.max(n_x)

    x = x2 - x1
    y = y2 - y1

    gapx = new_X - x
    gapy = new_Y - y

    new_x = x1 - new_X//2
    new_y = y1 - gapy//2

    if new_x < 0:
        new_x = 0
    if new_y < 0:
        new_y = 0

    if new_x > 3024 - new_X:
        new_x = 3024 - new_X - 1
    if new_y > 3024 - new_Y:
        new_y = 3024 - new_Y - 1

    new_msk = msk_arr[new_x: new_x + new_X, new_y: new_y + new_Y]
    new_img = image_arr[new_x: new_x + new_X, new_y: new_y + new_Y]

    new_img_file = Image.fromarray(new_img)
    new_msk_file = Image.fromarray(new_msk, "P")
    new_img_file = new_img_file.resize((resizeto, resizeto))
    new_msk_file = new_msk_file.resize((resizeto, resizeto), Image.NEAREST)
    new_msk_file.putpalette(palette)
    new_img_file.save(img)
    new_msk_file.save(msk)
    new_img_file.close()
    new_msk_file.close()


def overlap_2_img(img1, img2, new_filename, preview):
    a = np.asarray(img1)
    b = np.asarray(img2)

    c = np.clip((a.astype(np.float32) + b.astype(np.float32)) / 2, 0, 255)
    c = c.astype(np.uint8)

    if preview:
        img = Image.fromarray(c)
        img.save("overlapped_img_2" + size + "/preview/" + new_filename + ".jpg")
        img.close()

    res = np.stack((a, b, c), axis=-1).astype(np.float16) / 255.0

    np.save("overlapped_img_2" + size + "/npy/" + new_filename + ".npy", res)



def overlap_2(preview=False):
    dirs = ["green", "clear", "white"]

    if "overlapped_msk_2" + size not in os.listdir():
        os.mkdir("overlapped_msk_2" + size)

    if "npy" not in os.listdir("overlapped_msk_2" + size):
        os.mkdir("overlapped_msk_2" + size + "/npy")

    if "overlapped_img_2" + size not in os.listdir():
        os.mkdir("overlapped_img_2" + size)

    if "npy" not in os.listdir("overlapped_img_2" + size):
        os.mkdir("overlapped_img_2" + size + "/npy")

    if preview:
        if "preview" not in os.listdir("overlapped_img_2" + size):
            os.mkdir("overlapped_img_2" + size + "/preview")

        if "preview" not in os.listdir("overlapped_msk_2" + size):
            os.mkdir("overlapped_msk_2" + size + "/preview")

    for d in dirs:
        msks = os.listdir(d + "/msk")
        imgs = os.listdir(d + "/img")
        msks.sort()
        imgs.sort()

        for i in range(len(msks)):
            img1 = Image.open(d + "/img/" + imgs[i])
            msk1 = Image.open(d + "/msk/" + msks[i])
            X = imgs[i].split(".")[0]

            for j in range(i + 1, len(msks)):
                print(d + "/msk/" + msks[i], d + "/msk/" + msks[j])
                Y = imgs[j].split(".")[0]
                msk2 = Image.open(d + "/msk/" + msks[j])
                new_filename, ordered = overlap_2_msk(msk1, msk2, d, X, Y, preview)
                msk2.close()

                img2 = Image.open(d + "/img/" + imgs[j])
                if ordered:
                    overlap_2_img(img1, img2, new_filename, preview)
                else:
                    overlap_2_img(img2, img1, new_filename, preview)
                img2.close()

            img1.close()
            msk1.close()


def crop_and_resize():
    dirs = ["green", "clear", "white"]
    for d in dirs:
        msks = os.listdir(d + "/msk")
        imgs = os.listdir(d + "/img")
        msks.sort()
        imgs.sort()
        for i in range(len(msks)):
            resize_image(d + "/img/" + imgs[i],
                         d + "/msk/" + msks[i],
                         new_X=2016, new_Y=2016,
                         resizeto=int(size[1:]),
                         histogram_stretch=False)

overlap_2(True)
